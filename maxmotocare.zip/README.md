# MaxMotoCare

This is the official website for **MaxMotoCare**.

## How to Run Locally
1. Clone this repository.
2. Open `index.html` in your browser.

## Deploying to GitHub Pages
1. Go to repository settings.
2. Under **Pages**, select `main` branch and `/ (root)`.
3. Save — your site will be live at:
   `https://your-username.github.io/maxmotocare/`
